"""
src/guard.py
------------
Guard kiểm tra ràng buộc ngữ nghĩa dựa trên DFG Footprint cho S-NAP Hybrid.

Phương pháp luận (methodology)
- Từ tập vết huấn luyện, tính quan hệ directly-follows a>b (đếm tần suất).
- Suy diễn "footprint" gồm 3 quan hệ:
    a -> b  (causal)      nếu a>b và không b>a (sau lọc ngưỡng)
    a || b  (parallel)    nếu a>b và b>a
    a #  b  (conflict)    nếu không a>b và không b>a
- Lọc nhiễu theo min_count (số lần tối thiểu) và min_ratio (tỷ lệ cnt(a>b) / sum(a>*)).
- Guard online:
    • Nếu (last, candidate) ∈ conflict → REJECT
    • Nếu (last, candidate) ∈ causal hoặc ∈ parallel → ACCEPT
    • Nếu unknown → mặc định nương tay (ACCEPT) để tránh loại nhầm (có thể siết tuỳ dataset)

Khả năng & API
- Guard(...): khởi tạo với ngưỡng lọc (min_count, min_ratio).
- fit_from_traces(traces): học footprint (hoặc simple pairs fallback).
- is_allowed(prev, cand): kiểm tra cặp (prev, cand) theo footprint đã học.

Ghi chú
- Với log nhiều noise, tăng min_count hoặc min_ratio để làm quan hệ ổn định hơn.
- Có sẵn chế độ fallback "allowed_pairs" (chỉ cần cặp a>b xuất hiện ≥1 lần) nếu muốn đơn giản.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# DỮ LIỆU & CẤU HÌNH
# ---------------------------------------------------------------------------

@dataclass
class Footprint:
    """Lưu trữ quan hệ footprint ở dạng các tập hợp có hướng (directed)."""
    causal: Set[Tuple[str, str]]        # a -> b
    parallel: Set[Tuple[str, str]]      # a || b (lưu cả 2 hướng (a,b) và (b,a))
    conflict: Set[Tuple[str, str]]      # a # b  (lưu cả 2 hướng)


@dataclass
class FootprintConfig:
    """
    Cấu hình lọc nhiễu cho phép suy diễn quan hệ đáng tin cậy hơn.
    - min_count: tối thiểu số lần xuất hiện trực tiếp a>b để xem xét (mặc định 1).
    - min_ratio: tỷ lệ tối thiểu count(a>b) / (count(a>* ) + 1e-9) để tránh tín hiệu quá yếu.
                 Ví dụ 0.01 nghĩa là cần >=1% trong tổng chuyển tiếp từ 'a'.
    """
    min_count: int = 1
    min_ratio: float = 0.0


# ---------------------------------------------------------------------------
# TIỆN ÍCH: DIRECTLY-FOLLOWS & FOOTPRINT
# ---------------------------------------------------------------------------

def directly_follows_counts(traces: Iterable[List[str]]) -> Counter:
    """
    Đếm tần suất a>b (a trực tiếp theo sau bởi b) từ tập vết.
    Returns:
        Counter: {(a,b): count}
    """
    c = Counter()
    for t in traces:
        if not t or len(t) < 2:
            continue
        for i in range(len(t) - 1):
            c[(t[i], t[i + 1])] += 1
    return c


def _outgoing_totals(df_counts: Counter) -> Dict[str, int]:
    """Tổng số lần 'rẽ' từ mỗi nút a: sum_b count(a,b)."""
    tot: Dict[str, int] = defaultdict(int)
    for (a, b), v in df_counts.items():
        tot[a] += v
    return dict(tot)


def _passes_threshold(a: str, b: str, df_counts: Counter, totals: Dict[str, int], cfg: FootprintConfig) -> bool:
    """Kiểm tra (a>b) có đủ mạnh để giữ lại theo min_count/min_ratio."""
    cnt = df_counts.get((a, b), 0)
    if cnt < max(1, cfg.min_count):
        return False
    if cfg.min_ratio > 0.0:
        denom = float(totals.get(a, 0)) + 1e-9
        if (cnt / denom) < cfg.min_ratio:
            return False
    return True


def compute_footprint_relations(
    traces: Iterable[List[str]],
    cfg: Optional[FootprintConfig] = None,
) -> Footprint:
    """
    Suy diễn footprint quan hệ từ tập vết với lọc nhiễu.

    Args:
        traces: Iterable các vết (list[str]).
        cfg: FootprintConfig để lọc co-occurrence yếu (mặc định None -> không lọc).
    Returns:
        Footprint: tập quan hệ (causal, parallel, conflict) dạng có hướng.
    """
    cfg = cfg or FootprintConfig()
    df = directly_follows_counts(traces)
    totals = _outgoing_totals(df)

    # greater[a] = {b | a>b vượt ngưỡng}
    greater: Dict[str, Set[str]] = defaultdict(set)
    acts: Set[str] = set()
    for (a, b), v in df.items():
        acts.add(a); acts.add(b)
        if _passes_threshold(a, b, df, totals, cfg):
            greater[a].add(b)

    # Xây quan hệ
    causal: Set[Tuple[str, str]] = set()
    parallel_pairs: Set[Tuple[str, str]] = set()   # lưu dạng không có hướng (sorted tuple)
    for a in acts:
        for b in acts:
            if a == b:
                continue
            ab = b in greater.get(a, set())
            ba = a in greater.get(b, set())
            if ab and not ba:
                causal.add((a, b))
            elif ab and ba:
                parallel_pairs.add(tuple(sorted((a, b))))

    # Convert song song/ xung đột sang hướng
    parallel_dir: Set[Tuple[str, str]] = set()
    for a, b in parallel_pairs:
        parallel_dir.add((a, b))
        parallel_dir.add((b, a))

    conflict_dir: Set[Tuple[str, str]] = set()
    for a in acts:
        for b in acts:
            if a == b:
                continue
            ab = b in greater.get(a, set())
            ba = a in greater.get(b, set())
            if not ab and not ba:
                conflict_dir.add((a, b))

    return Footprint(causal=causal, parallel=parallel_dir, conflict=conflict_dir)


# ---------------------------------------------------------------------------
# GUARD API CẤP THẤP (HÀM)
# ---------------------------------------------------------------------------

def guard_check_dfg(candidate: str, prefix: List[str], fp: Footprint) -> bool:
    """
    Guard chi tiết bằng DFG footprint:
    - Nếu (last, candidate) ∈ conflict -> REJECT (False)
    - Nếu ∈ causal hoặc ∈ parallel -> ACCEPT (True)
    - Nếu unknown -> cho qua theo nguyên tắc bảo thủ (True)
    """
    if not prefix:
        return True
    last = prefix[-1]
    pair = (last, candidate)

    if pair in fp.conflict:
        return False
    if (pair in fp.causal) or (pair in fp.parallel):
        return True
    return True  # không biết: nương tay


def guard_check(candidate: str, prefix: List[str], allowed_pairs: Set[Tuple[str, str]]) -> bool:
    """
    Guard đơn giản theo cặp trực tiếp (fallback):
    True nếu (last, candidate) có trong allowed_pairs (DFG edges).
    """
    if not prefix:
        return True
    last = prefix[-1]
    return (last, candidate) in allowed_pairs


# ---------------------------------------------------------------------------
# TIỆN ÍCH BỔ TRỢ
# ---------------------------------------------------------------------------

def footprint_from_traces(
    traces: Iterable[List[str]],
    min_count: int = 1,
    min_ratio: float = 0.0,
) -> Footprint:
    """Helper gọn: tính footprint với cấu hình thường dùng."""
    cfg = FootprintConfig(min_count=min_count, min_ratio=min_ratio)
    return compute_footprint_relations(traces, cfg=cfg)


def allowed_pairs_from_traces(traces: Iterable[List[str]]) -> Set[Tuple[str, str]]:
    """Trả tập cặp trực tiếp (a,b) có xuất hiện >=1 lần — dùng cho guard đơn giản."""
    df = directly_follows_counts(traces)
    return {pair for pair, cnt in df.items() if cnt > 0}


# ---------------------------------------------------------------------------
# LỚP GUARD CẤP CAO (dùng trong pipeline)
# ---------------------------------------------------------------------------

class Guard:
    """
    Lớp bao bọc Footprint Guard cho pipeline HybridSNAP.

    - Khởi tạo với ngưỡng lọc (min_count, min_ratio).
    - fit_from_traces(traces): học footprint; đồng thời chuẩn bị allowed_pairs (fallback).
    - is_allowed(prev, cand): kiểm tra theo footprint; nếu chưa có footprint, dùng allowed_pairs.
    """

    def __init__(self, min_count: int = 1, min_ratio: float = 0.0, use_footprint: bool = True) -> None:
        self.min_count = int(min_count)
        self.min_ratio = float(min_ratio)
        self.use_footprint = bool(use_footprint)

        self._footprint: Optional[Footprint] = None
        self._allowed_pairs: Set[Tuple[str, str]] = set()

    def fit_from_traces(self, traces: Iterable[List[str]]) -> None:
        traces = list(traces)
        self._allowed_pairs = allowed_pairs_from_traces(traces)
        if self.use_footprint:
            self._footprint = footprint_from_traces(
                traces, min_count=self.min_count, min_ratio=self.min_ratio
            )
        else:
            self._footprint = None

    def is_allowed(self, prev: Optional[str], cand: str) -> bool:
        if prev is None or cand is None:
            return True
        if self._footprint is not None:
            return guard_check_dfg(cand, [prev], self._footprint)
        # fallback: chỉ cần (prev, cand) từng xuất hiện
        return (prev, cand) in self._allowed_pairs
