# src/utils/__init__.py
# ---------------------
"""
Tiện ích chung cho dự án S-NAPX.

Hiện tại gồm:
- config: load & merge YAML config
- datasets: load CSV thành EvalSample + traces_for_seq
"""
